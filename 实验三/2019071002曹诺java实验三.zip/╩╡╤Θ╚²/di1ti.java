package 实验三;

public class di1ti {
    public static void main(String[] args) {
        System.out.println("实验三第一题");
    }
}

class People{
    protected double  height;
    protected double  weight;

    public void speakHello() {

    }

    public void averageHeight(){

    }
    public void averageWeight(){

    }
}

class ChinaPeople extends People{
    public void speakHello() {

    }

    public void averageHeight(){

    }
    public void averageWeight(){

    }
    public void chinaGongfu(){

    }
}

class AmericanPeople extends People{
    public void speakHello() {

    }

    public void averageHeight(){

    }
    public void averageWeight(){

    }
    public void americanBoxing(){

    }
}
class BeijingPeople extends ChinaPeople{
    public void beijingOpera(){

    }
    public void speakHello() {

    }

    public void averageHeight(){

    }
    public void averageWeight(){

    }
}