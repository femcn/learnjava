import examples.has.geom.Circle;
import examples.has.geom.Geometry;
import examples.has.geom.Rectangle;
public class MainClass {
}
