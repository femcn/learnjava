package examples.has.geom;

public class Geometry {
}
