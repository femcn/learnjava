package examples.has.geom;

public class Circle {
}
